// Aedes module import
const aedes = require('aedes')();

// ---------------------------------------
// Config for normal mqtt
const server = require('net').createServer(aedes.handle);
const brokerPort = 1884;

// API for normal mqtt
server.listen(brokerPort, () => {
  console.log(`[Aedes] Broker started and listening to port ${brokerPort}`);
});


// ----------------------------------------
// Config for websocket
const httpServer = require('http').createServer();
const ws = require('websocket-stream');
const port = 8888;

// Create websocket connection
ws.createServer({ 
  server: httpServer 
}, aedes.handle);

httpServer.listen(port, function () {
  console.log('websocket server listening on port ', port)
});


// ----------------------------------------
// Express server -> serve static files
const express = require('express');
const app = express();
const PORT = 3001; // website port

// Static folder location
app.use(express.static('public'));

// Run server
app.listen(PORT, () => console.log(`Server listening on port: ${PORT}`));